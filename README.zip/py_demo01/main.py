# # Imports
# from pyspark import SparkConf
# from pyspark.sql import SparkSession

# # Create a SparkConf object
# conf = SparkConf().setAppName("SparkByExamples.com").setMaster("local[2]").set("spark.executor.memory", "2g")

# # Create a SparkSession object
# spark = SparkSession.builder.config(conf=conf).getOrCreate()

# # Retrieve the SparkConf object from the SparkContext
# conf = spark.sparkContext.getConf()

# # Print the configuration settings
# print("spark.app.name = ", conf.get("spark.app.name"))
# print("spark.master = ", conf.get("spark.master"))
# print("spark.executor.memory = ", conf.get("spark.executor.memory"))

# # from pyspark import SparkContext
from pyspark.sql import SparkSession

# Create a SparkSession object
spark = (
    SparkSession.builder
    .master("local[2]")
    .appName("Word Count")
    .config("spark.executor.memory", "2g")
    .getOrCreate()
    )

# Retrieve the SparkConf object from the SparkContext
conf = spark.sparkContext.getConf()

# Print the configuration settings
print("spark.app.name = ", conf.get("spark.app.name"))
print("spark.master = ", conf.get("spark.master"))
print("spark.executor.memory = ", conf.get("spark.executor.memory"))

data = [('James','','Smith','1991-04-01','M',3000),
  ('Michael','Rose','','2000-05-19','M',4000),
  ('Robert','','Williams','1978-09-05','M',4000),
  ('Maria','Anne','Jones','1967-12-01','F',4000),
  ('Jen','Mary','Brown','1980-02-17','F',-1)
]

columns = ["firstname","middlename","lastname","dob","gender","salary"]
df = spark.createDataFrame(data=data, schema = columns)
df.show()


df = spark.read.csv("/tmp/resources/zipcodes.csv")
df.printSchema()


# Create SparkSession 
# spark = SparkSession.builder \
#       .master("local[1]") \
#       .appName("SparkByExamples.com") \
#       .getOrCreate()

# # Retrieve the SparkConf object from the SparkContext
# conf = spark.sparkContext.getConf()

# # Print the configuration settings
# print("spark.app.name = ", conf.get("spark.app.name"))
# print("spark.master = ", conf.get("spark.master"))
# print("spark.executor.memory = ", conf.get("spark.executor.memory"))
