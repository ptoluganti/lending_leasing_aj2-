# Setup Steps

``` bash
python -m venv .venv

source .venv/bin/active


```

```python

pip3 install pyspark

# Spark SQL
pip3 install pyspark[sql]
# pandas API on Spark
pip3 install pyspark[pandas_on_spark] plotly  # to plot your data, you can install plotly together.
# Spark Connect
pip3 install pyspark[connect]


```
